# Kenneth Riggs — Fab Academy 2026

Static GitHub Pages site. Upload all files and folders to the repository root.

## Pages
- Home: index.html
- About: about.html
- Fab Lab Journey: journey.html
- Weekly Projects: projects.html
- VR Hub: vr-hub.html
- Contact: contact.html
- Weekly page template: week-template.html

## Assets
- Kenneth notebook portrait: assets/images/kenneth-notebook-portrait.png
- VR Hub refined concept: assets/images/vr-hub-concept.png
- Original hand sketch: assets/images/vr-hub-hand-sketch.jpg
