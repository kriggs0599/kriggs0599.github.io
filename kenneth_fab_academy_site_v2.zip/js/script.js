
const toggle=document.querySelector('.menu-toggle');
const menu=document.querySelector('.nav-menu');
if(toggle&&menu){toggle.addEventListener('click',()=>menu.classList.toggle('open'));}
const current=document.body.dataset.page;
document.querySelectorAll('.nav-menu a').forEach(a=>{if(a.dataset.page===current)a.classList.add('active');});
const io=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting)e.target.classList.add('visible')}),{threshold:.08});
document.querySelectorAll('.reveal').forEach(el=>io.observe(el));
