# Kenneth Riggs — Portfolio Website (v2)

A responsive, five-page GitHub Pages portfolio. Files: `index.html` (Home), `about.html`, `skills.html`, `projects.html`, `contact.html`, `style.css`, and `script.js`.

## Publish

1. Back up your current GitHub repository.
2. Open `https://github.com/kriggs0599/kriggs0599.github.io`.
3. On the **main** branch select **Add file → Upload files**.
4. Upload the **contents** of this folder at repository root (not this folder or the ZIP). GitHub will replace matching filenames.
5. Commit the changes, then verify `https://kriggs0599.github.io/`.

## Navigation and transitions

Each page is a real HTML file. Relative links work on GitHub Pages and when hosted on any static server. The site uses CSS cross-document View Transitions in supporting browsers, a small fade fallback otherwise, and IntersectionObserver reveal effects. Users with reduced-motion preferences get minimal animation.

No build tool or dependencies are needed. Google Fonts uses a web connection; system font fallbacks remain available.

## Content notes

Professional details and projects are summaries; review before public publishing. No personal email or third-party student data is included.
