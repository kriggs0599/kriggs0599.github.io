(() => {
  const menuButton = document.getElementById('menu-toggle');
  const menu = document.getElementById('nav-links');
  if (menuButton && menu) {
    menuButton.addEventListener('click', () => {
      const isOpen = menuButton.getAttribute('aria-expanded') === 'true';
      menuButton.setAttribute('aria-expanded', String(!isOpen));
      menu.classList.toggle('is-open', !isOpen);
    });
    menu.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
      menu.classList.remove('is-open');
      menuButton.setAttribute('aria-expanded', 'false');
    }));
  }
  const year = document.getElementById('year');
  if (year) year.textContent = new Date().getFullYear();

  // Reveal enhancement; sections remain visible when JS is unavailable.
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (!reducedMotion && 'IntersectionObserver' in window) {
    const targets = document.querySelectorAll('.reveal, .info-card, .project-card, .project-detail, .credential');
    targets.forEach(el => el.classList.add('will-reveal'));
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: .08, rootMargin: '0px 0px -30px 0px' });
    targets.forEach(el => observer.observe(el));
  }

  // Native cross-document view transitions handle eligible same-origin navigations.
  // Fallback animation works on older browsers and respects reduced motion.
  if (!reducedMotion && !('startViewTransition' in document)) {
    document.querySelectorAll('a[href]').forEach(a => {
      a.addEventListener('click', e => {
        if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || a.target === '_blank' || a.hasAttribute('download')) return;
        const url = new URL(a.href, location.href);
        if (url.origin !== location.origin || !/\.html$/.test(url.pathname) || (url.pathname === location.pathname && url.hash)) return;
        e.preventDefault();
        document.body.classList.add('page-leaving');
        window.setTimeout(() => { location.href = url.href; }, 220);
      });
    });
  }
})();
